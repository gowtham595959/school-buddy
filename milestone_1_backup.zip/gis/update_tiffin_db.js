const fs = require("fs");
const { Client } = require("pg");

async function main() {
  const client = new Client({
    user: "postgres",
    password: "postgres",
    host: "localhost",
    port: 5432,
    database: "schoolmap"
  });

  await client.connect();

  const merged = JSON.parse(fs.readFileSync("tiffin_boundary.geojson"));
  const individuals = JSON.parse(fs.readFileSync("tiffin_individual.geojson"));

  const sql = `
    UPDATE schools
    SET
      catchment_geojson = $1,
      postcode_geojson = $2
    WHERE name = 'The Tiffin Girls'' School'
  `;

  await client.query(sql, [merged, individuals]);
  await client.end();

  console.log("✔ Tiffin polygons written into DB");
}

main();
