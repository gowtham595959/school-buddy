const fs = require("fs");
const path = require("path");
const turf = require("@turf/turf");

const ROOT = "./postcode_geojson";

const TIFFIN_CODES = [
  "KT1","KT2","KT3","KT4","KT5","KT6","KT7","KT8","KT9","KT10","KT12","KT13","KT17","KT19",
  "TW1","TW2","TW3","TW4","TW5","TW7","TW8","TW9","TW10","TW11","TW12","TW13","TW14","TW15","TW16","TW17",
  "SW13","SW14","SW15","SW17","SW18","SW19","SW20",
  "W3","W4","W5","W7","W13","SM4","CR4"
];

function getLabel(props) {
  return String(
    props.name ||
    props.code ||
    props.pcd ||
    props.pcds ||
    props.district ||
    ""
  ).toUpperCase();
}

const individual = [];
const toMerge = [];

for (const code of TIFFIN_CODES) {
  const prefix = code.replace(/[0-9]/g, "");
  const file = path.join(ROOT, `${prefix}.geojson`);

  if (!fs.existsSync(file)) {
    console.log(`❌ Missing file for ${prefix}`);
    continue;
  }

  const raw = JSON.parse(fs.readFileSync(file));
  let match = null;

  for (const feat of raw.features) {
    if (getLabel(feat.properties) === code) {
      match = feat;
      break;
    }
  }

  if (!match) {
    console.log(`⚠️ No polygon for ${code} in ${file}`);
    continue;
  }

  console.log(`✔ Found ${code}`);

  const fixed = turf.cleanCoords(match);

  individual.push({
    type: "Feature",
    geometry: fixed.geometry,
    properties: { code }
  });

  toMerge.push(fixed);
}

console.log("\nTotal polygons found:", toMerge.length);

if (toMerge.length === 0) {
  console.log("❌ No polygons to merge.");
  process.exit(1);
}

console.log("Merging polygons… this may take a few seconds…");

let merged = toMerge[0];

for (let i = 1; i < toMerge.length; i++) {
  try {
    merged = turf.union(merged, toMerge[i]);
  } catch (err) {
    console.log(`⚠️ Union failed at index ${i}, retrying using dissolve`);
    const fc = turf.featureCollection(toMerge);
    merged = turf.dissolve(fc);
    break;
  }
}

const outputMerged = {
  type: "FeatureCollection",
  features: [ merged ]
};

const outputIndividuals = {
  type: "FeatureCollection",
  features: individual
};

fs.writeFileSync("tiffin_boundary.geojson", JSON.stringify(outputMerged, null, 2));
fs.writeFileSync("tiffin_individual.geojson", JSON.stringify(outputIndividuals, null, 2));

console.log("\n✅ DONE");
console.log("Generated:");
console.log(" - tiffin_boundary.geojson (merged catchment)");
console.log(" - tiffin_individual.geojson (all districts)");
