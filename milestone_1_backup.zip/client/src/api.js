import axios from "axios";

const API_BASE = "/api";

export const fetchSchools = async () => {
  const res = await axios.get(`${API_BASE}/schools`);
  return res.data;
};

export const fetchCatchment = async (id) => {
  const res = await axios.get(`${API_BASE}/schools/${id}/catchment`);
  return res.data;
};

export const fetchPostcodes = async (id) => {
  const res = await axios.get(`${API_BASE}/schools/${id}/postcodes`);
  return res.data;
};
