// client/src/MapView.jsx
import React, { useMemo, useState, useEffect } from "react";
import {
  MapContainer,
  TileLayer,
  Marker,
  Circle,
  Tooltip,
  GeoJSON
} from "react-leaflet";
import L from "leaflet";
import * as turf from "@turf/turf";
import "leaflet/dist/leaflet.css";

const HOME = [51.35, -0.17];

// Marker icons
const homeIcon = new L.Icon({
  iconUrl:
    "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png",
  iconSize: [25, 40],
  iconAnchor: [12, 40],
});

const schoolIcon = new L.Icon({
  iconUrl:
    "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-blue.png",
  iconSize: [25, 40],
  iconAnchor: [12, 40],
});

export default function MapView({ schools, selectedSchools }) {
  const [tiffin, setTiffin] = useState(null);

  // --- 1. Normalise & log bad schools ------------------------
  const allSchools = useMemo(() => {
    if (!Array.isArray(schools)) {
      console.warn("MapView: 'schools' is not an array:", schools);
      return [];
    }

    return schools.map((s) => ({
      ...s,
      // Make sure we always have numeric lat/lng if possible
      lat: typeof s.lat === "string" ? Number(s.lat) : s.lat,
      lng:
        s.lng !== undefined && s.lng !== null
          ? (typeof s.lng === "string" ? Number(s.lng) : s.lng)
          : // fallback if backend ever gives 'lon'
            (typeof s.lon === "string" ? Number(s.lon) : s.lon),
    }));
  }, [schools]);

  // Filter to selected schools, but only keep ones with good coords
  const visibleSchools = useMemo(() => {
    return allSchools.filter((s) => {
      if (!selectedSchools.includes(s.name)) return false;

      const latOk = Number.isFinite(s.lat);
      const lngOk = Number.isFinite(s.lng);

      if (!latOk || !lngOk) {
        console.warn("Skipping school with invalid coords:", s);
        return false;
      }

      return true;
    });
  }, [allSchools, selectedSchools]);

  // --- 2. Load Tiffin polygons when Tiffin is selected -------
  useEffect(() => {
    async function loadTiffin() {
      if (!selectedSchools.includes("The Tiffin Girls' School")) {
        setTiffin(null);
        return;
      }

      try {
        const res = await fetch("/api/schools/catchment/tiffin");
        if (!res.ok) {
          console.error("Failed to load Tiffin catchment:", res.status);
          setTiffin(null);
          return;
        }
        const data = await res.json();
        setTiffin(data);
      } catch (err) {
        console.error("Error fetching Tiffin catchment:", err);
        setTiffin(null);
      }
    }

    loadTiffin();
  }, [selectedSchools]);

  // --- 3. Render map -----------------------------------------
  return (
    <MapContainer
      center={HOME}
      zoom={11}
      style={{ height: "100%", width: "100%" }}
    >
      <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />

      {/* Home marker */}
      <Marker position={HOME} icon={homeIcon}>
        <Tooltip>Home</Tooltip>
      </Marker>

      {/* Non-Tiffin schools: Wallington & Nonsuch (and others in future) */}
      {visibleSchools.map((s) => {
        const pos = [s.lat, s.lng];
        const radius = s.radius_m;

        let color = "blue";
        if (s.name.includes("Wallington")) color = "green";
        if (s.name.includes("Nonsuch")) color = "purple";

        return (
          <React.Fragment key={s.id}>
            <Marker position={pos} icon={schoolIcon}>
              <Tooltip>{s.name}</Tooltip>
            </Marker>

            {Number.isFinite(radius) && radius > 0 && (
              <Circle
                center={pos}
                radius={radius}
                pathOptions={{
                  color,
                  fillColor: color,
                  fillOpacity: 0.2,
                }}
              >
                <Tooltip>
                  {s.name} catchment: {(radius / 1000).toFixed(2)} km
                </Tooltip>
              </Circle>
            )}
          </React.Fragment>
        );
      })}

      {/* Tiffin merged boundary */}
      {tiffin?.merged && (
        <GeoJSON
          key="tiffin-merged"
          data={tiffin.merged}
          style={{
            color: "#1f77b4",
            weight: 3,
            fillOpacity: 0.05,
          }}
        />
      )}

      {/* Tiffin individual postcode polygons */}
      {tiffin?.postcodes && (
        <GeoJSON
          key="tiffin-postcodes"
          data={tiffin.postcodes}
          style={{
            color: "#1f77b4",
            weight: 1,
            fillOpacity: 0.02,
          }}
          onEachFeature={(feature, layer) => {
            const code = feature?.properties?.code;
            if (!code) return;

            try {
              const center = turf.center(feature).geometry.coordinates; // [lng, lat]
              layer.bindTooltip(code, {
                permanent: true,
                direction: "center",
                className: "tiffin-label",
              });
            } catch (e) {
              console.warn("Could not compute label center for feature", e);
            }
          }}
        />
      )}
    </MapContainer>
  );
}
