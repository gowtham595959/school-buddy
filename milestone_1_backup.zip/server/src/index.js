// server/src/index.js

const express = require("express");
const cors = require("cors");

// Routers
const schoolsRouter = require("./routes/schools");
const tiffinRouter = require("./routes/tiffin");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Mount Tiffin router EXACTLY where the frontend uses it
app.use("/api/schools/catchment/tiffin", tiffinRouter);

// General school routes
app.use("/api/schools", schoolsRouter);

app.get("/", (req, res) => {
  res.json({ message: "School Buddy API is running" });
});

app.use((err, req, res, next) => {
  console.error("Server Error:", err);
  res.status(500).json({ error: "Server error" });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
