// server/src/routes/schools.js

const express = require("express");
const pool = require("../db");

const router = express.Router();

router.get("/", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        id,
        name,
        lat,
        lon AS lng,
        radius_m,
        catchment_geojson,
        postcode_geojson
      FROM schools
      ORDER BY id
    `);

    res.json(result.rows);
  } catch (err) {
    console.error("Error loading schools:", err);
    res.status(500).json({ error: "Failed to load schools" });
  }
});

module.exports = router;
