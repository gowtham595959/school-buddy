// server/src/routes/tiffin.js

const express = require("express");
const fs = require("fs");
const path = require("path");

const router = express.Router();

// Correct absolute paths to GIS directory
const boundaryPath = "/workspaces/school-buddy/gis/tiffin_boundary.geojson";
const postcodePath = "/workspaces/school-buddy/gis/tiffin_individual.geojson";

// GET /api/schools/catchment/tiffin
router.get("/", (req, res) => {
  try {
    const boundary = JSON.parse(fs.readFileSync(boundaryPath, "utf8"));
    const postcodes = JSON.parse(fs.readFileSync(postcodePath, "utf8"));

    res.json({
      merged: boundary,
      postcodes: postcodes
    });
  } catch (error) {
    console.error("❌ Tiffin catchment load error:", error);
    res.status(500).json({ error: "Failed to load tiffin catchment data" });
  }
});

module.exports = router;
