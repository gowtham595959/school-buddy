const express = require("express");
const router = express.Router();
const db = require("../db");

// GET merged Tiffin boundary + individual polygons
router.get("/tiffin", async (req, res) => {
  try {
    const result = await db.query(`
      SELECT 
        catchment_geojson,
        postcode_geojson
      FROM schools
      WHERE name = 'The Tiffin Girls'' School'
      LIMIT 1
    `);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Tiffin not found" });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error("Error loading Tiffin boundary:", err);
    res.status(500).json({ error: "Server error" });
  }
});

module.exports = router;
