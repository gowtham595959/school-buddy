import React from "react";

function kmToMiles(km) {
  if (typeof km !== "number") return null;
  return km * 0.621371;
}

function formatDuration(minutes) {
  if (typeof minutes !== "number") return "";
  if (minutes < 60) return `${minutes} Min`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${h} Hr${h > 1 ? "s" : ""} ${m} Min`;
}

function modeLabel(mode) {
  if (!mode) return "";
  return mode.charAt(0).toUpperCase() + mode.slice(1);
}

function modeEmoji(mode) {
  switch (mode) {
    case "driving":
      return "🚗";
    case "transit":
      return "🚌";
    case "walking":
      return "🚶";
    case "bicycling":
      return "🚴";
    default:
      return "🧭";
  }
}

export default function TransportButton({
  route,
  onClick,
  isActive,
  optionIndex,

  // ✅ ADDITIVE
  onMouseEnter,
  onMouseLeave,
}) {
  if (!route) return null;

  const miles = kmToMiles(route.distance_km);
  const milesText = typeof miles === "number" ? `${miles.toFixed(1)} mi` : "";
  const durationText = formatDuration(route.duration_minutes);

  const modeText =
    optionIndex != null
      ? `${modeLabel(route.mode)} ${optionIndex + 1}`
      : modeLabel(route.mode);

  return (
    <div
      onClick={onClick}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") onClick?.();
      }}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 8,
        padding: "8px 10px",
        borderRadius: 8,
        border: "1px solid #e5e5e5",
        marginTop: 8,
        cursor: "pointer",
        background: isActive ? "#eef5ff" : "#fff",
      }}
    >
      <div
        style={{
          width: 95,
          display: "flex",
          alignItems: "center",
          gap: 6,
          whiteSpace: "nowrap",
        }}
      >
        <span style={{ width: 18, textAlign: "center" }}>
          {modeEmoji(route.mode)}
        </span>
        <span style={{ fontWeight: 600 }}>{modeText}</span>
      </div>

      <div style={{ width: 6, textAlign: "center", fontWeight: 600 }}>:</div>

      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 12,
          fontSize: 13,
          whiteSpace: "nowrap",
        }}
      >
        <span>{durationText}</span>
        <span style={{ color: "#666" }}>{milesText}</span>
      </div>
    </div>
  );
}
