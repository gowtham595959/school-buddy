#!/usr/bin/env bash
# scripts/codeRestart.sh
#
# Convenience script to restart BOTH:
#   - backend (Express on port 5000)
#   - frontend (React dev server on port 3000)
#
# Usage:
#   cd scripts
#   ./codeRestart.sh

set -e

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "========================================"
echo " 🔄 SCHOOL BUDDY — FULL RESTART SCRIPT"
echo "========================================"
echo

# -------- Helper: kill process by port --------
kill_port() {
  local port="$1"
  local pid
  pid=$(lsof -t -i:"$port" || true)
  if [[ -n "$pid" ]]; then
    echo "⚠️  Port $port is in use by PID $pid — killing..."
    kill -9 "$pid" 2>/dev/null || true
  else
    echo "✅ Port $port is free."
  fi
}

echo "🛑 Stopping any running frontend..."
kill_port 3000
echo

echo "🛑 Stopping any running backend..."
kill_port 5000
echo

echo "⏳ Waiting 2 seconds..."
sleep 2
echo

# -------- Start backend --------
echo "🚀 Starting backend..."
(
  cd "$ROOT_DIR/server"
  # Run in background, output to backend.log
  npm run dev >"$ROOT_DIR/server/backend.log" 2>&1 &
)
sleep 2

# Check if backend actually started
if ! lsof -t -i:5000 >/dev/null 2>&1; then
  echo "❌ Backend failed to start!"
  echo "▶️ Check logs: $ROOT_DIR/server/backend.log"
  exit 1
fi
echo "✅ Backend is running on port 5000."
echo

# -------- Start frontend --------
echo "🚀 Starting frontend..."
(
  cd "$ROOT_DIR/client"
  npm start >/dev/null 2>&1 &
)
sleep 2

if ! lsof -t -i:3000 >/dev/null 2>&1; then
  echo "❌ Frontend failed to start!"
  echo "▶️ Check client logs in the Codespaces terminal."
  exit 1
fi

echo "✅ Frontend is running on port 3000."
echo
echo "🎉 Restart complete."
